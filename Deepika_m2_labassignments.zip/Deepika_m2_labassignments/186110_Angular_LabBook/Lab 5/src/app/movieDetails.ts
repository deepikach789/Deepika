import {Movies} from './movies';
export const movies:Movies[]=[
    {name:'Baahubali',rating:4.5,genre:'Drama'},
    {name:'24',rating:4.0,genre:'Fiction'},
    {name:'Leader',rating:3.5,genre:'Satire'},
    {name:'Magadheera',rating:3.5,genre:'Drama'},
    {name:'One',rating:4.5,genre:'Fiction'},

];